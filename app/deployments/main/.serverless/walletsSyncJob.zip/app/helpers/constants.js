// TODO: Hardcode your Postgres credentials here
export const POSTGRES = {
    "postgresUsername": "potion",
    "postgresPassword": "password123",
    "postgresDatabase": "potion",
    "postgresPort": 5432,
    "postgresURL": "localhost"
};

export const WALLETS = [
    "5rkPDK4JnVAumgzeV2Zu8vjggMTtHdDtrsd5o9dhGZHD",
    "suqh5sHtr8HyJ7q8scBimULPkPpA557prMG47xCHQfK",
    "AJ6MGExeK7FXmeKkKPmALjcdXVStXYokYNv9uVfDRtvo",
    "73LnJ7G9ffBDjEBGgJDdgvLUhD5APLonKrNiHsKDCw5B",
    "CyaE1VxvBrahnPWkqm5VsdCvyS2QmNht2UFrKJHga54o",
    "4S9U8HckRngscHWrW418cG6Suw62dhEZzmyrT2hxSye5",
    "4S9U8HckRngscHWrW418cG6Suw62dhEZzmyrT2hxSye5",
    "F72vY99ihQsYwqEDCfz7igKXA5me6vN2zqVsVUTpw6qL",
    "5TuiERc4X7EgZTxNmj8PHgzUAfNHZRLYHKp4DuiWevXv",
    "AbcX4XBm7DJ3i9p29i6sU8WLmiW4FWY5tiwB9D6UBbcE",
    "BCnqsPEtA1TkgednYEebRpkmwFRJDCjMQcKZMMtEdArc",
    "DfMxre4cKmvogbLrPigxmibVTTQDuzjdXojWzjCXXhzj",
    "7ABz8qEFZTHPkovMDsmQkm64DZWN5wRtU7LEtD2ShkQ6",
    "7VBTpiiEjkwRbRGHJFUz6o5fWuhPFtAmy8JGhNqwHNnn",
    "DNfuF1L62WWyW3pNakVkyGGFzVVhj4Yr52jSmdTyeBHm",
    "8deJ9xeUvXSJwicYptA9mHsU2rN2pDx37KWzkDkEXhU6",
    "ATFRUwvyMh61w2Ab6AZxUyxsAfiiuG1RqL6iv3Vi9q2B",
    "7N4bAyZX6z39RozQh7GC8VQmgjvjkkWmSyAt1wdMjEmq",
    "7iabBMwmSvS4CFPcjW2XYZY53bUCHzXjCFEFhxeYP4CY",
    "6LChaYRYtEYjLEHhzo4HdEmgNwu2aia8CM8VhR9wn6n7",
    "8MaVa9kdt3NW4Q5HyNAm1X5LbR8PQRVDc1W8NMVK88D5",
    "GfXQesPe3Zuwg8JhAt6Cg8euJDTVx751enp9EQQmhzPH",
    "DKgvpfttzmJqZXdavDwTxwSVkajibjzJnN2FA99dyciK",
    "DeVjHYTEZEi7Wvcvfjz8KZMzpuZpijABgutSfXn1BxjX",
    "m7Kaas3Kd8FHLnCioSjCoSuVDReZ6FDNBVM6HTNYuF7"
];